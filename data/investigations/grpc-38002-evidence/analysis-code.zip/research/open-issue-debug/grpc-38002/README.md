# gRPC #38002 reporter-profile analysis

This analyzes the original uploaded profiles offline. It does not run the
reporter's server, reconstruct coroutine/request creation, or validate a repair.

The input archive is linked in `profile-analysis.json`; its SHA-256 is
`0041f5ca5be75f7af0de3cc349d29b37be3757cb116a651fbe48126798d94df3`.
Extract its regular files into
`perf-out/open-issue-debug/grpc-38002/source/attachment/`, retaining its
`GRPC_CPU_38002/C++` and `GRPC_CPU_38002/Java` subdirectories. Place the
original archive at
`perf-out/open-issue-debug/grpc-38002/source/GRPC_CPU_38002.tar.gz`.

From the bundle root, with `perf` available:

```sh
uv run --no-project --python /path/to/python \
  research/open-issue-debug/grpc-38002/analyze_profiles.py
uv run --no-project --python /path/to/python --with pytest -m pytest \
  tests/test_merge_perf_scripts.py -q
```

The analyzer matches text event headers against the binary records by TID,
timestamp and sampling period. Source symbols come from the supplied text;
matching headers does not independently verify the symbolization or unwinding.
Inclusive path groups overlap. Directory names do not prove optimization flags.
The two original sample totals are not a matched per-request CPU ratio.
