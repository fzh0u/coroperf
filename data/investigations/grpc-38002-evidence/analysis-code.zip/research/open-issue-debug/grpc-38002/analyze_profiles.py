"""Analyze the reporter's CPU profiles without inventing request ancestry."""
from collections import Counter
from hashlib import sha256
import importlib.util
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'perf-out/open-issue-debug/grpc-38002'
INPUT = BASE / 'source/attachment/GRPC_CPU_38002'
spec = importlib.util.spec_from_file_location('perf_blocks', ROOT / 'scripts/merge_perf_scripts.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)
HEADER = re.compile(r'^(.*?)\s+(\d+)\s+(\d+\.\d+):\s+(\d+)\s+([^:]+):')
FRAME = re.compile(r'\s*[0-9a-f]+\s+(.+)\s+\((.*)\)\s*$')
GROUPS = {'request_handler': 'CallData::processRequest',
          'subscriber_handler': 'sendMessageToSubscriberHandler',
          'response_finish': 'ServerAsyncResponseWriter<accountadmin::AccountAdminMessage>::Finish',
          'completion_queue': 'CompletionQueue::',
          'timer_manager': 'TimerManager', 'protobuf': 'google::protobuf::'}


def analyze(label):
    folder = INPUT / label
    raw = folder / 'out.perf'
    samples = list(reader.blocks(raw))
    assert samples
    threads, leaves, inclusive, periods, groups = (Counter() for _ in range(5))
    unknown = empty = debug_paths = truncated = 0
    tids = set()
    for timestamp, lines in samples:
        h = HEADER.match(lines[0])
        assert h is not None, lines[0]
        threads[h[1]] += 1
        tids.add(h[2])
        periods[int(h[4])] += 1
        stack = []
        for line in lines[1:]:
            if not line.strip():
                continue
            frame = FRAME.match(line)
            assert frame is not None, line
            stack.append((re.sub(r'\+0x[0-9a-f]+$', '', frame[1]), frame[2]))
        names = [name for name, _ in stack]
        empty += not names
        unknown += '[unknown]' in names
        debug_paths += any('/debug/' in path for _, path in stack)
        truncated += len(stack) >= 127
        if stack:
            leaves[stack[0][0]] += 1
            inclusive.update(set(names))
        for key, needle in GROUPS.items():
            if any(needle in name for name in names):
                groups[key] += 1
    # Independently read event headers from the binary, without needing its DSOs.
    binary = subprocess.run(['perf', 'script', '-i', str(folder/'perf.data'),
                             '--no-demangle', '-F', 'comm,tid,time,period,event'],
                            text=True, capture_output=True, check=True)
    binary_events = [line for line in binary.stdout.splitlines() if line.strip()]
    assert len(binary_events) == len(samples)
    binary_headers = [HEADER.match(line) for line in binary_events]
    assert all(binary_headers)
    assert [(h[2], float(h[3]), int(h[4])) for h in binary_headers] == [
        (HEADER.match(lines[0])[2], timestamp, int(HEADER.match(lines[0])[4]))
        for timestamp, lines in samples]
    return dict(sample_count=len(samples), binary_event_count=len(binary_events),
                binary_headers_match_text=True,
                first_sample_s=samples[0][0], last_sample_s=samples[-1][0],
                observed_span_s=samples[-1][0]-samples[0][0],
                period_histogram_ns=dict(periods),
                sampled_period_sum_ns=sum(period*count for period, count in periods.items()),
                thread_names=dict(threads), sampled_thread_ids=len(tids),
                samples_with_unknown_frame=unknown, empty_stacks=empty,
                samples_with_debug_directory_dso=debug_paths,
                stacks_at_127_frames=truncated, inclusive_groups=dict(groups),
                top_leaf_samples=leaves.most_common(15),
                top_inclusive_samples=inclusive.most_common(15),
                files=[dict(name=name, sha256=sha256((folder/name).read_bytes()).hexdigest())
                       for name in ('out.perf', 'perf.data', 'flamegraph.svg')],
                binary_reader_warnings=binary.stderr.splitlines())


if __name__ == '__main__':
    result = dict(issue='https://github.com/grpc/grpc/issues/38002',
                  source_archive='https://github.com/user-attachments/files/17569042/GRPC_CPU_38002.tar.gz',
                  archive_sha256=sha256((BASE/'source/GRPC_CPU_38002.tar.gz').read_bytes()).hexdigest(),
                  analysis_kind='offline reporter-profile analysis',
                  original_workload_local_runs=0, root_cause_confirmed=False,
                  repair_validated=False, profiles={label:analyze(label) for label in ('C++','Java')},
                  collector_scope='CoroPerf perf-script reader only. No request, coroutine '
                                  'creation or activation records were present; no ancestry '
                                  'was reconstructed.',
                  limits=['Directory names do not establish compiler optimization flags.',
                          'Java JIT symbols and many native call-chain frames are unresolved.',
                          'Inclusive groups overlap and must not be added.',
                          'Sample totals are not request latency, per-RPC cost, a matched '
                          'throughput ratio or a validated repair effect.',
                          'The reporter describes 60 TPS for 60 seconds per arm; actual '
                          'completed RPC counts, payloads, startup/warmup and binaries are absent.'])
    (BASE/'profile-analysis.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({label: {k:value[k] for k in ['sample_count','samples_with_unknown_frame',
          'samples_with_debug_directory_dso','inclusive_groups','thread_names']}
          for label,value in result['profiles'].items()}, indent=2))
