#!/usr/bin/env python3
"""Merge perf-script event blocks by their common monotonic timestamp."""

from __future__ import annotations

import argparse
import re
from pathlib import Path


HEADER_RE = re.compile(
    r"^\s*.+?\s+\d+(?:\s+\[\d+\])?\s+(?P<time>\d+\.\d+):"
)


def blocks(path: Path):
    current_time: float | None = None
    current_lines: list[str] = []
    for raw in path.read_text(errors="replace").splitlines(keepends=True):
        match = HEADER_RE.match(raw)
        if match:
            if current_lines:
                yield current_time or 0.0, current_lines
            current_time = float(match.group("time"))
            current_lines = [raw]
        elif current_lines:
            current_lines.append(raw)
    if current_lines:
        yield current_time or 0.0, current_lines


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, action="append", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    merged = [item for path in args.input for item in blocks(path)]
    merged.sort(key=lambda item: item[0])
    args.output.write_text(
        "".join(
            "".join(lines) + ("\n" if lines and lines[-1].strip() else "")
            for _, lines in merged
        )
    )
    print(f"merge_perf_scripts=pass inputs={len(args.input)} blocks={len(merged)} output={args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
