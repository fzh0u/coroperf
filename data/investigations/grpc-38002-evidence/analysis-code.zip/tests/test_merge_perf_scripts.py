"""Keep samples from perf comm names containing spaces separate."""
import importlib.util
from pathlib import Path


def test_compiler_thread_header_does_not_merge_into_previous_stack(tmp_path):
    source = Path(__file__).resolve().parents[1] / 'scripts/merge_perf_scripts.py'
    spec = importlib.util.spec_from_file_location('merge_perf', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    capture = tmp_path / 'out.perf'
    capture.write_text(
        'grpc-nio-worker 50873 87680.494805: 10101010 cpu-clock:pppH:\n'
        '  7f0c2d582ae0 recv+0x1 (lib.so)\n\n'
        'C1 CompilerThre 50853 87680.763237: 10101010 cpu-clock:pppH:\n'
        '  7f0c2d582ae0 compile+0x2 (libjvm.so)\n\n'
        'event_engine 50472 [003] 87681.000000: 10101010 cpu-clock:pppH:\n'
        '  7f0c2d582ae0 run+0x3 (libgrpc.so)\n')
    samples = list(module.blocks(capture))
    assert [time for time, _ in samples] == [87680.494805, 87680.763237, 87681.0]
    assert 'compile' not in ''.join(samples[0][1])
    assert 'recv' not in ''.join(samples[1][1])
