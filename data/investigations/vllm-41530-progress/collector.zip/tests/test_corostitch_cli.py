import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def load_cli_module():
    spec = importlib.util.spec_from_file_location(
        "corostitch_cli", ROOT / "scripts" / "corostitch.py"
    )
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.path.insert(0, str(ROOT / "scripts"))
    try:
        spec.loader.exec_module(module)
    finally:
        sys.path.pop(0)
    return module


def test_list_adapters_exposes_scoped_and_runtime_routes():
    result = subprocess.run(
        [str(ROOT / "bin/corostitch"), "list-adapters"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    assert "transparent-asyncio" in result.stdout
    assert "remote-asyncio" in result.stdout
    assert "tokio-service" in result.stdout
    assert "boost-asio-service" in result.stdout
    assert "runtime-attach" in result.stdout
    assert "assembly-attach" in result.stdout
    assert "native-runtime" in result.stdout
    assert "async-hooks-ebpf" in result.stdout


def test_python_helper_exit_does_not_overwrite_parent_capture(tmp_path):
    program = tmp_path / "parent.py"
    program.write_text('''\
import asyncio
import json
import os
import subprocess
import sys

helper_code = """
import asyncio
import sys
sys.stdin.read()
async def helper_work():
    await asyncio.sleep(.01)
asyncio.run(helper_work())
"""
helper = subprocess.Popen([sys.executable, '-B', '-c', helper_code], stdin=subprocess.PIPE)
async def parent_work():
    await asyncio.sleep(.02)
asyncio.run(parent_work())
print(json.dumps({'parent_pid': os.getpid(), 'helper_pid': helper.pid}), flush=True)
# Interpreter shutdown closes the pipe after the parent's capture is flushed.
# The inherited helper then flushes its own, different Task graph.
''')
    capture = tmp_path / "graph.json"
    env = dict(os.environ, PYTHONPATH=str(ROOT / "agents/python"),
               COROSTITCH_ENABLE="1", COROSTITCH_OUT=str(capture),
               COROSTITCH_SAMPLE_INTERVAL=".005")
    env.pop("COROSTITCH_OUTPUT_OWNER_PID", None)
    result = subprocess.run([sys.executable, '-B', str(program)], env=env,
                            check=True, capture_output=True, text=True, timeout=10)
    pids = json.loads(result.stdout)
    parent = json.loads(capture.read_text())
    assert any(s.get('function_name') == 'parent_work' for s in parent['segments'])
    assert not any(s.get('function_name') == 'helper_work' for s in parent['segments'])
    child_file = tmp_path / f"graph.pid-{pids['helper_pid']}.json"
    child = json.loads(child_file.read_text())
    assert any(s.get('function_name') == 'helper_work' for s in child['segments'])
    assert parent['agent']['process_id'] == pids['parent_pid']
    assert child['agent']['process_id'] == pids['helper_pid']
    assert parent['agent']['output_owner_process_id'] == child['agent']['output_owner_process_id'] == pids['parent_pid']


def test_python_helper_with_its_own_output_keeps_the_canonical_path(tmp_path):
    child_output = tmp_path / 'child.json'
    program = tmp_path / 'separate-output.py'
    program.write_text('''\
import asyncio
import json
import os
import subprocess
import sys
child_env = dict(os.environ, COROSTITCH_OUT=sys.argv[1])
child = subprocess.run([sys.executable, '-B', '-c',
    'import asyncio,os; asyncio.run(asyncio.sleep(.01)); print(os.getpid())'],
    env=child_env, check=True, capture_output=True, text=True)
asyncio.run(asyncio.sleep(.01))
print(json.dumps({'parent_pid': os.getpid(), 'helper_pid': int(child.stdout)}))
''')
    capture = tmp_path / 'parent.json'
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'agents/python'),
               COROSTITCH_ENABLE='1', COROSTITCH_OUT=str(capture))
    result = subprocess.run([sys.executable, '-B', str(program), str(child_output)],
                            env=env, check=True, capture_output=True, text=True, timeout=10)
    pids = json.loads(result.stdout)
    for path, pid in [(capture, pids['parent_pid']), (child_output, pids['helper_pid'])]:
        graph = json.loads(path.read_text())
        assert graph['segments']
        assert graph['agent']['process_id'] == graph['agent']['output_owner_process_id'] == pid


def test_transparent_python_launch_closes_exception_and_cancel_tasks(tmp_path):
    out = tmp_path / "transparent"
    subprocess.run(
        [
            str(ROOT / "bin/corostitch"),
            "run",
            "--language",
            "python",
            "--adapter",
            "transparent-asyncio",
            "--out-dir",
            str(out),
            "--sample-interval",
            "0.005",
            "--",
            "python3",
            "examples/python-transparent-asyncio/app.py",
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    run_summary = json.loads((out / "run-summary.json").read_text())
    graph = json.loads((out / "graph.json").read_text())
    child = run_summary["child_summary"]
    assert run_summary["status"] == "pass"
    assert child["creates"] == child["exits"]
    assert child["samples"] > 0
    assert child["active_reported"] == 0
    exit_reasons = {
        segment.get("exit_reason")
        for segment in graph["segments"]
        if segment["capture_reason"] == "exit"
    }
    assert {"return", "exception", "cancel"} <= exit_reasons
    assert (out / "corostitch-report.html").exists()


def test_python_unawaited_capture_records_allocation_at_shutdown(tmp_path):
    program = tmp_path / "unawaited.py"
    program.write_text("""\
import asyncio
import gc
import warnings

async def ignored():
    pass

async def forgotten(cycle):
    pass

with warnings.catch_warnings():
    warnings.simplefilter("ignore", RuntimeWarning)
    ignored()

asyncio.run(ignored())
gc.disable()
cycle = []
cycle.append(forgotten(cycle))
del cycle
""")
    out = tmp_path / "capture"
    subprocess.run(
        [
            str(ROOT / "bin/coroPerf"), "run", "--language", "python",
            "--adapter", "transparent-asyncio", "--capture-unawaited",
            "--out-dir", str(out), "--", "python3", "-B", str(program),
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=True,
    )
    child = json.loads((out / "run-summary.json").read_text())["child_summary"]
    assert child["unawaited_capture"] is True
    assert child["unawaited_origins"] == child["unawaited_warnings"] == 1
    assert child["creates"] == child["exits"]
    graph = json.loads((out / "graph.json").read_text())
    edge, = (e for e in graph["edges"] if e["kind"] == "unawaited_coroutine_origin")
    allocation, warning = (graph["segments"][edge[k]] for k in ("from", "to"))
    allocation_line = program.read_text().splitlines().index("cycle.append(forgotten(cycle))") + 1
    assert allocation["frames"][-1] == f"<module>:{allocation_line}:{program}"
    assert warning["frames"][-1].startswith("_warn_unawaited_coroutine:")
    assert allocation["coroutine_object_id"] == warning["coroutine_object_id"]
    assert allocation["coroutine_id"] is warning["coroutine_id"] is None
    assert allocation["timestamp_ns"] == warning["timestamp_ns"]
    stderr = (out / "stderr.log").read_text()
    assert stderr.count("was never awaited") == 1
    assert "coroutine 'forgotten' was never awaited" in stderr
    assert "CPython emitted a never-awaited warning for forgotten." in (out / "corostitch-report.html").read_text()


def test_python_attach_uses_retained_creation_stacks_and_tracks_unknown_origins(tmp_path):
    program = tmp_path / "attach.py"
    program.write_text("""\
import asyncio

async def child(gate):
    await gate.wait()

async def plain_task(start_child, gate):
    await start_child.wait()
    await asyncio.create_task(child(gate))

async def debug_task(gate):
    await gate.wait()

def spawn_debug(gate):
    return asyncio.create_task(debug_task(gate))

async def main():
    gate = asyncio.Event()
    start_child = asyncio.Event()
    plain = asyncio.create_task(plain_task(start_child, gate))
    loop = asyncio.get_running_loop()
    loop.set_debug(True)
    debug = spawn_debug(gate)
    loop.set_debug(False)
    await asyncio.sleep(0)
    import corostitch_agent as agent
    assert agent.attach_current_loop() == 3
    assert agent.attach_current_loop() == 0
    start_child.set()
    await asyncio.sleep(.04)
    gate.set()
    await asyncio.gather(plain, debug)

asyncio.run(main(), debug=False)
import corostitch_agent as agent
agent._write_output()
""")
    capture = tmp_path / "graph.json"
    env = dict(os.environ, PYTHONPATH=str(ROOT / "agents/python"),
               COROSTITCH_ENABLE="0", COROSTITCH_REMOTE_ATTACH="1", COROSTITCH_OUT=str(capture),
               COROSTITCH_SAMPLE_INTERVAL=".005")
    subprocess.run([sys.executable, "-B", str(program)], env=env, check=True, capture_output=True, text=True)
    data = json.loads(capture.read_bytes())
    segments = data["segments"]
    plain, debug, child = (
        next(s for s in segments if s.get("function_name") == name)
        for name in ("plain_task", "debug_task", "child")
    )
    assert plain["capture_reason"] == "task_discovered"
    assert plain["frames"] == []
    assert debug["capture_reason"] == "create"
    assert debug["creation_evidence"] == "asyncio-task-source-traceback"
    assert debug["timestamp_ns"] is None and debug["observed_timestamp_ns"] > 0
    line = program.read_text().splitlines().index("    return asyncio.create_task(debug_task(gate))") + 1
    assert f"spawn_debug:{line}:{program}" in debug["frames"]
    assert all("attach_current_loop" not in f for f in debug["frames"])
    assert debug["parent_coroutine_id"] is None
    assert child["capture_reason"] == "create" and child["timestamp_ns"] > debug["observed_timestamp_ns"]
    assert child["parent_coroutine_id"] == plain["coroutine_id"]
    edges = {(e["from"], e["to"], e["kind"]) for e in data["edges"]}
    for task in (plain, debug, child):
        samples = [s for s in segments
                   if s["capture_reason"] == "sample" and s["coroutine_id"] == task["coroutine_id"]]
        assert samples
        assert all(((task["id"], s["id"], "base_to_sample") in edges)
                   == (task is not plain) for s in samples)
    summary = load_cli_module().summarize_graph(data, set())
    assert summary["pass"] and summary["boundary_conservation"]
    assert summary["task_discoveries"] == 2 and summary["recovered_creates"] == 1
    assert summary["samples_without_base"] == summary["samples_from_discovered_tasks"] > 0
    subprocess.run([str(ROOT / "bin/coroPerf"), "analyze", "--input", str(capture),
                    "--out-dir", str(tmp_path / "analysis")], cwd=ROOT, check=True, capture_output=True, text=True)
    normalized = json.loads((tmp_path / "analysis" / "graph.json").read_bytes())
    assert normalized["segments"][debug["id"]]["timestamp_ns"] is None


def test_html_report_is_self_contained_and_searchable(tmp_path):
    graph = tmp_path / "graph.json"
    graph.write_text(json.dumps({
        "segments": [
            {"id": 1, "coroutine_id": "task-1", "capture_reason": "create", "frames": ["caller"]},
            {"id": 2, "coroutine_id": "task-1", "capture_reason": "sample", "frames": ["worker"]},
        ],
        "edges": [{"from": 1, "to": 2, "kind": "base_to_sample"}],
    }))
    report = tmp_path / "report.html"
    subprocess.run([
        str(ROOT / "bin/corostitch"), "report", "--input", str(graph), "--output", str(report)
    ], cwd=ROOT, check=True)
    document = report.read_text()
    assert "task-1" in document
    assert "caller" in document and "worker" in document
    assert 'id="query"' in document and "COROSTITCH_EMBEDDED_DATA" in document
    assert '<script type="module" src=' not in document
    assert '<link rel="stylesheet" href=' not in document


def test_run_envelope_accepts_entry_return_adapters_and_dynamic_artifacts(tmp_path):
    cli = load_cli_module()
    out = tmp_path / "dotnet"
    out.mkdir()
    for name in ("samples.jsonl", "probes.json", "probe-status.json", "collector.json"):
        (out / name).write_text("{}\n")

    child = {
        "pass": True,
        "entries": 42,
        "returns": 42,
        "samples": 7,
        "active_threads": 0,
    }
    summary = cli.write_envelope(
        out,
        "dotnet",
        "jit-scoped-service",
        "scoped-jit",
        ["collector"],
        0,
        time.monotonic_ns(),
        child,
    )

    report = (out / "corostitch-report.md").read_text()
    assert summary["status"] == "pass"
    assert "`42` / `7` / `42`" in report
    assert "active after collection: `0`" in report
    assert all(any(path.endswith(name) for path in summary["artifacts"])
               for name in ("samples.jsonl", "probes.json", "probe-status.json", "collector.json"))
