"""Exercise the real uvloop factory, including an application Task subclass."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import pytest

ROOT=Path(__file__).resolve().parents[1]


@pytest.mark.parametrize('custom_factory',[False,True])
def test_uvloop_retains_creation_history_and_application_factory(tmp_path,custom_factory):
    if importlib.util.find_spec('uvloop') is None:
        pytest.skip('uvloop is an optional runtime')
    program=tmp_path/'uvloop_target.py'
    program.write_text('''import asyncio, json, sys, uvloop
custom = sys.argv[1] == 'True'
class ApplicationTask(asyncio.Task): pass
created = []
root_coroutine = None
def app_factory(loop, coro, **kwargs):
    created.append(coro.__qualname__)
    return ApplicationTask(coro, loop=loop, **kwargs)
async def payload():
    await asyncio.sleep(.025)
    return 7
async def request():
    child = asyncio.create_task(payload())
    if custom: assert isinstance(child, ApplicationTask)
    return await child
async def main():
    global root_coroutine
    root_coroutine = asyncio.current_task().get_coro().__qualname__
    assert type(asyncio.get_running_loop()).__module__.startswith('uvloop')
    child = asyncio.create_task(request())
    if custom: assert isinstance(child, ApplicationTask)
    return await child
if custom:
    loop = uvloop.new_event_loop()
    loop.set_task_factory(app_factory)
    with asyncio.Runner(loop_factory=lambda: loop) as runner:
        result = runner.run(main())
else:
    result = uvloop.run(main())
print(json.dumps({'result': result, 'application_factory_calls': created,
                  'root_coroutine': root_coroutine}))
''')
    clean={k:v for k,v in os.environ.items() if not k.startswith(('COROSTITCH_','COROPERF_'))}
    command=[sys.executable,'-B',str(program),str(custom_factory)]
    baseline=subprocess.run(command,env=clean,text=True,capture_output=True,check=True,timeout=15)
    spec=tmp_path/'spec.json'
    spec.write_text(json.dumps({'python_functions':[{'file_suffix':program.name,'names':['payload']}]}))
    graph_path=tmp_path/'graph.json'
    env=dict(clean,COROSTITCH_ENABLE='1',COROSTITCH_OUT=str(graph_path),
             COROPERF_BOUNDARY_SPEC=str(spec),COROSTITCH_SAMPLE_INTERVAL='.005',
             PYTHONPATH=os.pathsep.join(filter(None,[str(ROOT/'agents/python'),clean.get('PYTHONPATH')])) )
    observed=subprocess.run(command,env=env,text=True,capture_output=True,check=True,timeout=15)
    assert observed.stdout==baseline.stdout
    graph=json.loads(graph_path.read_text())
    creates=[s for s in graph['segments'] if s['capture_reason']=='create']
    names={s['function_name'] for s in creates}
    assert {'request','payload',json.loads(baseline.stdout)['root_coroutine']} <= names
    child=next(s for s in creates if s['function_name']=='payload')
    parent=next(s for s in creates if s['function_name']=='request')
    assert child['parent_coroutine_id']==parent['coroutine_id']
    boundaries=[s for s in graph['segments'] if s.get('semantic',{}).get('function')=='payload']
    assert boundaries and all(s['coroutine_id']==child['coroutine_id'] for s in boundaries)
    assert graph['agent']['sampling_tick_times_ns']


def test_uvloop_creation_history_survives_a_blocked_process(tmp_path):
    if importlib.util.find_spec('uvloop') is None:
        pytest.skip('uvloop is an optional runtime')
    program=tmp_path/'uvloop_blocked.py'
    program.write_text('''import asyncio, threading, uvloop
def block(native_task_id):
    threading.Event().wait()
async def main():
    block(id(asyncio.current_task()))
uvloop.run(main())
''')
    spec=tmp_path/'spec.json'
    spec.write_text(json.dumps({'python_functions':[{'file_suffix':program.name,
        'names':['block'],'locals':{'native_task_id':'native_task_id'}}]}))
    graph_path=tmp_path/'graph.json';journal=tmp_path/'journal'
    clean={k:v for k,v in os.environ.items() if not k.startswith(('COROSTITCH_','COROPERF_'))}
    env=dict(clean,COROSTITCH_ENABLE='1',COROSTITCH_OUT=str(graph_path),
             COROPERF_BOUNDARY_SPEC=str(spec),COROPERF_BOUNDARY_JOURNAL_DIR=str(journal),
             PYTHONPATH=str(ROOT/'agents/python'))
    child=subprocess.Popen([sys.executable,'-B',str(program)],env=env)
    try:
        deadline=time.monotonic()+5
        rows=[];entry=None
        while time.monotonic()<deadline:
            assert child.poll() is None
            rows=[]
            for path in journal.glob('*.jsonl'):
                for line in path.read_text().splitlines():
                    try:rows.append(json.loads(line))
                    except json.JSONDecodeError:pass
            entry=next((r for r in rows if r.get('semantic',{}).get('phase')=='call'),None)
            if entry is not None:break
            time.sleep(.01)
        assert entry is not None
        assert not graph_path.exists(),'The process has not reached normal graph export'
        creation=next((r for r in rows if r['capture_reason']=='create'
                       and r['coroutine_id']==entry['coroutine_id']),None)
        assert creation is not None,'Persist creation before the process can block'
        native_id=entry['semantic']['locals']['native_task_id']
        assert hex(native_id) in creation['coroutine_id']
        assert creation['id']<entry['id']
    finally:
        child.terminate();child.wait(timeout=5)
