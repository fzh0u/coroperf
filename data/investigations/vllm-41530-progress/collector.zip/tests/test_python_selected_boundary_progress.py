"""Collector checks; these fixtures are not vLLM failure reproductions."""
import json
from hashlib import sha256
import os
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[1]


def settings(tmp_path, filename, names):
    spec = tmp_path / "boundaries.json"
    spec.write_text(json.dumps({
        "profile_new_threads": True,
        "python_functions": [{"file_suffix": filename, "names": names,
                              "locals": {"scheduled": "scheduled",
                                         "draft_lengths": {"path": "drafts", "mode": "lengths"},
                                         "device": "device"}}]}))
    return dict(os.environ, PYTHONPATH=str(ROOT / "agents/python"),
                COROSTITCH_ENABLE="1", COROSTITCH_OUT=str(tmp_path / "graph.json"),
                COROPERF_BOUNDARY_SPEC=str(spec),
                COROPERF_BOUNDARY_JOURNAL_DIR=str(tmp_path / "journal"))


def test_selected_metadata_thread_and_async_identity(tmp_path):
    program = tmp_path / "boundary_workload.py"
    program.write_text('''import asyncio, json, threading
class DeviceAccessTrap:
    def __array__(self): raise AssertionError("must not inspect device data")
    def cpu(self): raise AssertionError("must not copy device data")
    def item(self): raise AssertionError("must not synchronize device data")
def calculate_budget(scheduled, drafts, device):
    return sum(scheduled.values())
async def traced_request():
    device = DeviceAccessTrap()
    answer = calculate_budget({"request": 6}, {"request": [91, 92]}, device)
    await asyncio.sleep(0)
    answer += calculate_budget({"request": 7}, {"request": [93]}, device)
    return answer
async def main():
    result = await asyncio.create_task(traced_request())
    thread = threading.Thread(target=calculate_budget,
        args=({"thread-request": 8}, {"thread-request": []}, DeviceAccessTrap()))
    thread.start(); thread.join()
    print(json.dumps({"answer": result}))
asyncio.run(main())
''')
    baseline = subprocess.run([sys.executable, '-B', str(program)],
                              capture_output=True, text=True, check=True, timeout=10)
    env = settings(tmp_path, program.name, ['calculate_budget', 'traced_request'])
    launch_env = {key: val for key, val in os.environ.items()
                  if not key.startswith(('COROSTITCH_', 'COROPERF_'))}
    traced = subprocess.run([sys.executable, '-B', str(ROOT/'tools/vllm-progress/launch.py'),
                             '--out', str(tmp_path), '--spec', env['COROPERF_BOUNDARY_SPEC'],
                             '--', sys.executable, '-B', str(program)], env=launch_env,
                            capture_output=True, text=True, check=True, timeout=10)
    assert traced.stdout == baseline.stdout == '{"answer": 13}\n'
    graph = json.loads((tmp_path / 'graph.json').read_text())
    events = [s for s in graph['segments'] if s.get('semantic')]
    budget = [s for s in events if s['semantic']['function'] == 'calculate_budget'
              and s['semantic']['phase'] == 'call']
    assert len(budget) == 3
    assert len({s['semantic']['activation_token'] for s in budget}) == 3
    assert budget[0]['semantic']['locals']['draft_lengths'] == {'request': 2}
    assert budget[0]['semantic']['locals']['device']['type'] == 'DeviceAccessTrap'
    assert budget[0]['semantic']['source']['file_sha256'] == sha256(program.read_bytes()).hexdigest()
    thread = next(s for s in budget if 'thread-request' in s['semantic']['locals']['scheduled'])
    assert thread['coroutine_id'] is None
    assert thread['thread_id'] != budget[0]['thread_id']
    request = [s for s in events if s['semantic']['function'] == 'traced_request']
    assert 'suspend' in {s['semantic']['phase'] for s in request}
    assert len({s['semantic']['activation_token'] for s in request}) == 1
    assert len({s['semantic']['call_index'] for s in request}) == 1
    assert len({s['coroutine_id'] for s in request}) == 1 and request[0]['coroutine_id']
    assert budget[0]['semantic']['parent_activation_token'] == request[0]['semantic']['activation_token']
    assert thread['semantic']['parent_activation_token'] is None
    journal = next((tmp_path / 'journal').glob('host-progress.*.jsonl'))
    persisted = [json.loads(line) for line in journal.read_text().splitlines()]
    assert len(persisted) == len(events)
    assert graph['agent']['boundary_journal_error'] is None


def test_blocked_sync_entry_is_persisted_before_process_exit(tmp_path):
    program = tmp_path / 'blocking_boundary.py'
    program.write_text('import threading\ndef block_forever():\n    threading.Event().wait()\nblock_forever()\n')
    env = settings(tmp_path, program.name, ['block_forever'])
    process = subprocess.Popen([sys.executable, '-B', str(program)], env=env,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        deadline = time.monotonic() + 5
        records = []
        while time.monotonic() < deadline:
            for path in (tmp_path / 'journal').glob('*.jsonl'):
                try:
                    records = [json.loads(line) for line in path.read_text().splitlines()]
                except json.JSONDecodeError:
                    continue
            if records:
                break
            if process.poll() is not None:
                raise AssertionError(process.communicate())
            time.sleep(.01)
        assert process.poll() is None
        assert records and records[0]['semantic']['function'] == 'block_forever'
        assert records[0]['semantic']['phase'] == 'call'
        assert records[0]['coroutine_id'] is None
        assert not (tmp_path / 'graph.json').exists()
    finally:
        if process.poll() is None:
            process.terminate()
        process.communicate(timeout=5)


def test_fork_worker_starts_a_fresh_history_and_boundary_sequence(tmp_path):
    if not hasattr(os, 'fork'):
        return
    program = tmp_path/'fork_boundary.py'
    program.write_text('''import asyncio, json, os, sys
def calculate_budget(scheduled, drafts, device): return sum(scheduled.values())
async def parent_work():
    calculate_budget({"parent": 1}, {}, None)
asyncio.run(parent_work())
pid = os.fork()
if pid == 0:
    calculate_budget({"child": 2}, {}, None)
    async def child_work(): await asyncio.sleep(0)
    asyncio.run(child_work())
    sys.exit(0)
_, status = os.waitpid(pid, 0)
assert status == 0
print(json.dumps({"child_pid": pid}))
''')
    env = settings(tmp_path, program.name, ['calculate_budget'])
    result = subprocess.run([sys.executable, '-B', str(program)], env=env,
                            capture_output=True, text=True, check=True, timeout=10)
    pid = json.loads(result.stdout)['child_pid']
    child = json.loads((tmp_path/f'graph.pid-{pid}.json').read_text())
    assert not any(s.get('function_name') == 'parent_work' for s in child['segments'])
    assert any(s.get('function_name') == 'child_work' for s in child['segments'])
    boundaries = [s for s in child['segments'] if s.get('semantic')]
    assert boundaries[0]['semantic']['call_index'] == 1
    assert boundaries[0]['semantic']['parent_activation_token'] is None
    journal = [json.loads(line) for line in
               (tmp_path/'journal'/f'host-progress.{pid}.jsonl').read_text().splitlines()]
    assert all(s['process_id'] == pid for s in journal)
    assert all('parent' not in s['semantic']['locals']['scheduled'] for s in journal)
