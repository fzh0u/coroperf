# vLLM host-progress capture

This is a diagnostic collector for the inspected vLLM 0.33.0 source revision
`4ba787ec9959e566d3b587a796dff07673324da5`. The incident in issue 41530 has
not been reproduced or assigned a root cause by this collector.

The selected boundaries record RPC dispatch and response waits, worker RPC
entry/return, adaptive draft budgets, graph/DP dispatch inputs, and SHM queue
operations. Metadata includes source-file and bytecode hashes, process/native
thread identity, invocation tokens, and selected synchronous parent invocations.
The existing asyncio agent separately records actual Task creation/history;
a synchronous worker event has no fabricated coroutine identity.

## Run on the affected workload

From the root of the extracted collector bundle, use the Python environment
that already runs the affected vLLM installation:

```sh
uv run --no-project --python /path/to/environment/bin/python \
  tools/vllm-progress/launch.py --out /path/to/capture -- \
  /path/to/environment/bin/python -m vllm.entrypoints.openai.api_server \
  [the original server arguments]
```

The launcher preserves the command and worker start method. Keep the original
model, image/revision, topology and request workload, and compare against an
unprofiled run; do not substitute a smaller model and call it an incident
reproduction. Collection overhead and its effect on the failing schedule have
not been measured on vLLM.

Each process writes `journal/host-progress.PID.jsonl` before a selected Python
call can block. These files survive failure to reach normal graph export.
Normal termination also exports the existing task graphs, with child processes
using separate PID filenames. A terminated journal is an incomplete capture,
not proof that an unmatched call deadlocked. Check source hashes and coverage,
inspect worker/native stacks, and correlate the original input before drawing
causal conclusions. Graph timestamps and IDs are local to their process/run;
cross-host timing requires a separate alignment source.

`call_index` counts observed invocations of one function/resource in one
process. It is not a wire RPC ID. Cross-rank comparisons require coverage from
startup and consistent RPC ordering plus matching method/request progress;
index equality or request-count equality alone is not sufficient. Event tokens
and task history reset in a forked child. New-thread profiling is enabled, and
collection itself may perturb scheduling. The collector does not read device
tensors or observe CUDA/NCCL completion. It records bounded host metadata;
containers over 64 elements are explicitly marked truncated. It must not be
used as a production overhead result. Journals and in-memory graphs are not
rotated: choose a bounded diagnostic window and monitor their size.

## Source and collector checks

```sh
uv run --no-project --python /path/to/python \
  tools/vllm-progress/validate_spec.py /path/to/pinned/vllm \
  --out source-selection.json
uv run --no-project --with pytest --python /path/to/python -m pytest \
  tests/test_python_selected_boundary_progress.py \
  tests/test_corostitch_cli.py::test_python_helper_exit_does_not_overwrite_parent_capture -q
```

The source check finds 19 selected function entries. Four engineering checks
exercise metadata extraction without device reads, identity across async
suspension, thread/fork/process separation, and persistence before a blocked
process exits. Their fixtures are collector checks, not vLLM bug reproductions.
