#!/usr/bin/env python3
"""Check selected source names against a pinned checkout, without importing vLLM."""
import argparse
import ast
from hashlib import sha256
import json
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--spec', type=Path,
                        default=Path(__file__).with_name('boundaries-v0.33.json'))
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    spec = json.loads(args.spec.read_text())
    matches = []
    for rule in spec['python_functions']:
        path = args.source/rule['file_suffix']
        tree = ast.parse(path.read_text())
        names = []
        def visit(node, parents=()):
            if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                parents = parents+(node.name,)
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    names.append(('.'.join(parents), node.lineno))
            for child in ast.iter_child_nodes(node):
                visit(child, parents)
        visit(tree)
        for name in rule['names']:
            found = [(qualname, line) for qualname, line in names
                     if qualname.split('.')[-1] == name
                     and (not rule.get('qualname_suffix')
                          or qualname.endswith(rule['qualname_suffix']))]
            assert found, (rule['file_suffix'], name)
            matches.append(dict(file=rule['file_suffix'], function=name, matches=found,
                                source_sha256=sha256(path.read_bytes()).hexdigest()))
    result = dict(target_revision=spec['target_revision'], matches=matches,
                  scope='Source selection only; no model inference or incident reproduction')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2)+'\n')
    print(f'{len(matches)} source selections matched; no target execution')


if __name__ == '__main__':
    main()
