#!/usr/bin/env python3
"""Launch an unchanged command with selected CoroPerf host-progress capture."""
import argparse
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--spec', type=Path,
                        default=Path(__file__).with_name('boundaries-v0.33.json'))
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command
    if command and command[0] == '--':
        command = command[1:]
    if not command:
        parser.error('Supply the original Python/vLLM command after --')
    spec = args.spec.resolve()
    json.loads(spec.read_text())
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env.update(COROSTITCH_ENABLE='1', COROSTITCH_OUT=str(output/'graph.json'),
               COROPERF_BOUNDARY_SPEC=str(spec),
               COROPERF_BOUNDARY_JOURNAL_DIR=str(output/'journal'),
               PYTHONPATH=os.pathsep.join(filter(None,
                   [str(ROOT/'agents/python'), env.get('PYTHONPATH')])) )
    # A new launch owns its capture; descendants get independent PID files.
    env.pop('COROSTITCH_OUTPUT_OWNER_PATH', None)
    env.pop('COROSTITCH_OUTPUT_OWNER_PID', None)
    (output/'launch.json').write_text(json.dumps(dict(
        command=command, spec=str(spec),
        scope='Opt-in Python host progress; device/collective completion is not observed',
        worker_start_method_changed=False), indent=2)+'\n')
    os.execvpe(command[0], command, env)


if __name__ == '__main__':
    main()
