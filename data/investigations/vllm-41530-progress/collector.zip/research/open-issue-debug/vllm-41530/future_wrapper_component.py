"""Exercise the unmodified source-only FutureWrapper class, without an engine.

This is an isolated real-class collector check. The response callbacks below
are controlled external inputs, not a reproduction of issue41530.
"""
import ast
import asyncio
from collections import deque
from concurrent.futures import Future, InvalidStateError
from contextlib import suppress
from hashlib import sha256
import json
from pathlib import Path
import sys
from typing import Any, Callable

source = Path(sys.argv[1]).resolve()
tree = ast.parse(source.read_text())
node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'FutureWrapper')
namespace = dict(Future=Future, InvalidStateError=InvalidStateError, suppress=suppress,
                 deque=deque, Any=Any, Callable=Callable, __name__='vllm_source_component')
exec(compile(ast.Module(body=[node], type_ignores=[]), str(source), 'exec'), namespace)
FutureWrapper = namespace['FutureWrapper']
queue = deque()
order = []

def receive(label):
    order.append(label)
    if label == 'b':
        raise TimeoutError('controlled external response timeout')
    return 'answer-'+label

async def launch_request(label):
    return FutureWrapper(queue, lambda: receive(label))

async def submit_all():
    return [await asyncio.create_task(launch_request(label)) for label in ['a', 'b', 'c']]

futures = asyncio.run(submit_all())
assert futures[2].result() == 'answer-c'
assert futures[0].result() == 'answer-a'
try:
    futures[1].result()
except TimeoutError as error:
    assert str(error) == 'controlled external response timeout'
else:
    raise AssertionError('Expected the controlled callback error')
assert order == ['a', 'b', 'c'] and not queue
print(json.dumps(dict(component='unmodified FutureWrapper source class',
 source_sha256=sha256(source.read_bytes()).hexdigest(), response_order=order,
 future_object_ids=[str(id(f)) for f in futures], output='answer-a; TimeoutError; answer-c',
 scope='Isolated class/collector validation, zero engine/model/incident executions')))
