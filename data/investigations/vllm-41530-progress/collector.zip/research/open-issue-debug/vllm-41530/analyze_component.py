"""Check a bounded source-component capture; this is not incident diagnosis."""
import json
from pathlib import Path
import sys

root = Path(sys.argv[1]).resolve()
base = root / 'perf-out/open-issue-debug/vllm-41530'
baseline = json.loads((base / 'component-baseline.json').read_text())
profiled = json.loads((base / 'component-profiled.json').read_text())
assert {k: v for k, v in baseline.items() if k != 'future_object_ids'} == {
    k: v for k, v in profiled.items() if k != 'future_object_ids'}
graph = json.loads((base / 'component-capture/graph.json').read_text())
assert graph['agent']['boundary_journal_error'] is None
constructors = {}
waits = []
for segment in graph['segments']:
    event = segment.get('semantic', {})
    if not event:
        continue
    assert event['source']['file_sha256'] == profiled['source_sha256']
    if event['phase'] == 'call' and event['qualname'] == 'FutureWrapper.__init__':
        assert event['resource_id'] not in constructors
        constructors[event['resource_id']] = segment
    if event['phase'] == 'call' and event['qualname'] == 'FutureWrapper._wait_for_response':
        waits.append(segment)
assert len(constructors) == len(waits) == 3
assert [s['semantic']['resource_id'] for s in waits] == profiled['future_object_ids']
assert len({s['coroutine_id'] for s in constructors.values()}) == 3
joins = []
for wait in waits:
    event = wait['semantic']
    creation = constructors[event['resource_id']]
    assert creation['coroutine_id'] is not None and wait['coroutine_id'] is None
    assert creation['semantic']['locals']['response_closure'] == event['fields']['get_response']
    exits = [s for s in graph['segments'] if s['capture_reason'] == 'exit'
             and s['coroutine_id'] == creation['coroutine_id']]
    assert len(exits) == 1
    assert creation['timestamp_ns'] < exits[0]['timestamp_ns'] < wait['timestamp_ns']
    joins.append(dict(resource_id=event['resource_id'],
                      creator_task=creation['coroutine_id'],
                      creator_segment=creation['id'],
                      creator_exit_segment=exits[0]['id'],
                      wait_segment=wait['id'],
                      response_closure=event['fields']['get_response']))
result = dict(status='passed', scope=profiled['scope'],
              original_incident_runs=0, root_cause_confirmed=False,
              source_sha256=profiled['source_sha256'],
              baseline_profiled_outputs_match=True,
              exact_fixture_joins=joins,
              limits='Bounded live-object fixture only; these joins do not establish '
                     'production object-ID lifetime safety, wire RPC identity, rank '
                     'agreement, device progress, incident cause or overhead.')
out = base / 'component-validation.json'
out.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
