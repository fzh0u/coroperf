import os

if os.environ.get("COROSTITCH_ENABLE") == "1":
    import corostitch_agent  # noqa: F401
