"""Opt-in, selected boundary observations; no application names or expected values."""
import contextvars
import dis
import hashlib
from itertools import islice
import json
import os
from pathlib import Path
import sys
import threading


def value(item):
    if item is None or isinstance(item, (bool, int, float, str)):
        return item if not isinstance(item, str) else item[:160]
    if isinstance(item, bytes):
        return {"bytes_sha256": hashlib.sha256(item).hexdigest()}
    return {"type": type(item).__qualname__, "object_id": str(id(item))}


def selected_value(item, mode="value", depth=0):
    """Bounded, explicitly selected host metadata; never copy device tensors."""
    if mode == "length":
        return len(item) if isinstance(item, (dict, list, tuple, str, bytes)) else value(item)
    if mode == "lengths" and isinstance(item, dict):
        result = {str(k): selected_value(v, "length") for k, v in islice(item.items(), 64)}
        return {"items": result, "total_items": len(item), "truncated": True} if len(item) > 64 else result
    if depth >= 3:
        return value(item)
    if isinstance(item, dict):
        result = {str(k): selected_value(v, depth=depth + 1)
                  for k, v in islice(item.items(), 64)}
        return {"items": result, "total_items": len(item), "truncated": True} if len(item) > 64 else result
    if isinstance(item, (list, tuple)):
        result = [selected_value(v, depth=depth + 1) for v in item[:64]]
        return {"items": result, "total_items": len(item), "truncated": True} if len(item) > 64 else result
    return value(item)


def selected_local(frame, selection):
    if isinstance(selection, str):
        selection = {"path": selection}
    parts = selection["path"].split(".")
    try:
        obj = frame.f_locals[parts[0]]
        for part in parts[1:]:
            if isinstance(obj, dict):
                obj = obj[part]
            elif isinstance(obj, (tuple, list)) and part.isdecimal():
                obj = obj[int(part)]
            else:
                obj = getattr(obj, part)
        return selected_value(obj, selection.get("mode", "value"))
    except (AttributeError, LookupError, TypeError):
        return {"unavailable": True}


def install(emit):
    spec = json.loads(Path(os.environ["COROPERF_BOUNDARY_SPEC"]).read_text())
    if sys.getprofile() is not None:
        raise RuntimeError("Selected boundary profiles require an unused profile hook")
    if spec.get("profile_new_threads") and threading.getprofile() is not None:
        raise RuntimeError("Selected thread boundaries require an unused thread profile hook")
    functions = spec.get("python_functions", [])
    contexts = spec.get("contextvars", {})
    files = set(contexts.get("files", []))
    names = set(contexts.get("names", []))
    live_activations = {}
    activation_parents = {}
    activation_indexes = {}
    invocation_counts = {}
    source_fingerprints = {}
    next_activation = 0

    def after_fork():
        nonlocal next_activation
        live_activations.clear()
        activation_parents.clear()
        activation_indexes.clear()
        invocation_counts.clear()
        next_activation = 0

    if hasattr(os, "register_at_fork"):
        os.register_at_fork(after_in_child=after_fork)

    def profile(frame, event, arg):
        nonlocal next_activation
        if event == "c_return" and frame.f_code.co_filename in files:
            variable = getattr(arg, "__self__", None)
            operation = getattr(arg, "__name__", "")
            if isinstance(variable, contextvars.ContextVar) and variable.name in names and operation in ("get", "set", "reset"):
                try:
                    current = variable.get()
                except LookupError:
                    current = {"unset": True}
                emit("contextvar-" + operation, {"kind": "contextvar", "operation": operation,
                    "variable_id": str(id(variable)), "name": variable.name, "value": value(current)}, frame)
        if event not in ("call", "return"):
            return
        matched = False
        activation = None
        phase = None
        for rule in functions:
            if not frame.f_code.co_filename.endswith(rule["file_suffix"]) or frame.f_code.co_name not in rule["names"]:
                continue
            qualname = getattr(frame.f_code, "co_qualname", frame.f_code.co_name)
            if rule.get("qualname_suffix") and not qualname.endswith(rule["qualname_suffix"]):
                continue
            if frame.f_code not in source_fingerprints:
                try:
                    digest = hashlib.sha256(Path(frame.f_code.co_filename).read_bytes()).hexdigest()
                except OSError:
                    digest = None
                source_fingerprints[frame.f_code] = {
                    "file": frame.f_code.co_filename, "file_sha256": digest,
                    "bytecode_sha256": hashlib.sha256(frame.f_code.co_code).hexdigest()}
            resource = frame.f_locals.get(rule.get("resource", "self"))
            if not matched:
                matched = True
                if event == "call" and id(frame) not in live_activations:
                    next_activation += 1
                    live_activations[id(frame)] = next_activation
                    caller = frame.f_back
                    while caller is not None and id(caller) not in live_activations:
                        caller = caller.f_back
                    activation_parents[next_activation] = live_activations.get(id(caller)) if caller else None
                    invocation_key = (qualname, id(resource))
                    invocation_counts[invocation_key] = invocation_counts.get(invocation_key, 0) + 1
                    activation_indexes[next_activation] = invocation_counts[invocation_key]
                activation = live_activations.get(id(frame))
            fields = {}
            for attribute in rule.get("attributes", []):
                obj = resource
                try:
                    for part in attribute.split("."):
                        obj = getattr(obj, part)
                    fields[attribute] = value(obj)
                except (AttributeError, LookupError):
                    fields[attribute] = {"unavailable": True}
            opcode = dis.opname[frame.f_code.co_code[frame.f_lasti]] if frame.f_lasti >= 0 else "entry"
            phase = "suspend" if event == "return" and opcode.startswith("YIELD") else event
            emit("boundary-" + phase, {"kind": "python-function", "phase": phase,
                "function": frame.f_code.co_name, "resource_id": str(id(resource)),
                "qualname": qualname, "activation_id": str(id(frame)), "fields": fields,
                "source": source_fingerprints[frame.f_code],
                "activation_token": activation,
                "parent_activation_token": activation_parents.get(activation),
                "call_index": activation_indexes.get(activation),
                "locals": {key: selected_local(frame, selection)
                           for key, selection in rule.get("locals", {}).items()},
                "rank_environment": {key: os.environ[key] for key in spec.get("rank_environment", [])
                                     if key in os.environ},
                "result": value(arg) if event == "return" else None}, frame)
        if matched and event == "return" and phase != "suspend":
            closed = live_activations.pop(id(frame), None)
            activation_parents.pop(closed, None)
            activation_indexes.pop(closed, None)
    sys.setprofile(profile)
    if spec.get("profile_new_threads"):
        threading.setprofile(profile)
    if spec.get("sqlalchemy_pool"):
        from sqlalchemy import event
        from sqlalchemy.pool import Pool
        def observe(kind):
            def callback(connection, record, *args):
                emit("pool-" + kind, {"kind": "sqlalchemy-pool", "phase": kind,
                    "connection_id": str(id(connection)), "record_id": str(id(record))})
            return callback
        for kind in ("checkout", "checkin", "invalidate", "reset"):
            event.listen(Pool, kind, observe(kind))
