"""Transparent asyncio lifecycle and sampled-stack agent loaded by sitecustomize."""

from __future__ import annotations

import atexit
import asyncio
import json
import os
import sys
import threading
import time
import traceback
import weakref
from pathlib import Path
from typing import Any


OUTPUT = Path(os.environ.get("COROSTITCH_OUT", "perf-out/corostitch/python-transparent/graph.json"))
# Re-executed helpers inherit the output setting. Keep the original launch's
# canonical file; helpers write separate process-scoped captures beside it.
_output_key = str(OUTPUT.resolve())
if os.environ.get("COROSTITCH_OUTPUT_OWNER_PATH") != _output_key:
    os.environ["COROSTITCH_OUTPUT_OWNER_PATH"] = _output_key
    os.environ["COROSTITCH_OUTPUT_OWNER_PID"] = str(os.getpid())
_output_owner_pid = int(os.environ["COROSTITCH_OUTPUT_OWNER_PID"])
SAMPLE_INTERVAL = max(float(os.environ.get("COROSTITCH_SAMPLE_INTERVAL", "0.2")), 0.001)
STACK_LIMIT = max(int(os.environ.get("COROSTITCH_STACK_LIMIT", "32")), 1)
EXCEPTION_FILES = {str(Path(p).resolve()) for p in
                   os.environ.get("COROPERF_EXCEPTION_FILES", "").split(os.pathsep) if p}
REMOTE_MODE = os.environ.get("COROSTITCH_REMOTE_ATTACH") == "1"
CAPTURE_UNAWAITED = os.environ.get("COROPERF_CAPTURE_UNAWAITED") == "1"
FLUSH_SECONDS = max(float(os.environ.get("COROPERF_FLUSH_SECONDS", "0")), 0)
_last_flush = 0.0
BOUNDARY_JOURNAL_DIR = os.environ.get("COROPERF_BOUNDARY_JOURNAL_DIR")
_boundary_journal_fd = None
_boundary_journal_pid = None
_boundary_journal_error = None
_sampling_tick_times_ns: list[int] = []

_lock = threading.RLock()
_segments: list[dict[str, Any]] = []
_edges: list[dict[str, Any]] = []
_task_ids: weakref.WeakKeyDictionary[asyncio.Task[Any], str] = weakref.WeakKeyDictionary()
_base: dict[str, int] = {}
_latest: dict[str, int] = {}
_active: set[str] = set()
_sampled_loops: weakref.WeakSet[asyncio.AbstractEventLoop] = weakref.WeakSet()
_sample_handles: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.TimerHandle] = weakref.WeakKeyDictionary()
_generation = 0
_installed = False
_original_create_task = None
_patched_create_task = None
_remote_attach = False
_seeded_tasks = 0
_loop_factories: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, Any] = weakref.WeakKeyDictionary()
_unawaited_enabled = False


def _after_fork() -> None:
    """A worker starts a new identity domain; parent tasks are not its history."""
    global _lock, _segments, _edges, _task_ids, _base, _latest, _active
    global _sampled_loops, _sample_handles, _loop_factories, _generation
    global _sampling_tick_times_ns, _last_flush
    global _boundary_journal_fd, _boundary_journal_pid, _boundary_journal_error
    _lock = threading.RLock()
    _segments, _edges = [], []
    _task_ids = weakref.WeakKeyDictionary()
    _base, _latest, _active = {}, {}, set()
    _sampled_loops = weakref.WeakSet()
    _sample_handles, _loop_factories = weakref.WeakKeyDictionary(), weakref.WeakKeyDictionary()
    _generation, _sampling_tick_times_ns, _last_flush = 0, [], 0.0
    if _boundary_journal_fd is not None:
        os.close(_boundary_journal_fd)
    _boundary_journal_fd, _boundary_journal_pid, _boundary_journal_error = None, None, None


if hasattr(os, "register_at_fork"):
    os.register_at_fork(after_in_child=_after_fork)


def _frame_strings(raw_frames: list[Any]) -> list[str]:
    frames = []
    for item in raw_frames[-STACK_LIMIT:]:
        if isinstance(item, traceback.FrameSummary):
            frames.append(f"{item.name}:{item.lineno}:{item.filename}")
        else:
            frames.append(f"{item.f_code.co_name}:{item.f_lineno}:{item.f_code.co_filename}")
    return frames


def _push(task_id: str | None, reason: str, frames: list[str], **extra: Any) -> int:
    segment_id = len(_segments)
    segment = {
        "id": segment_id,
        "coroutine_id": task_id,
        "capture_reason": reason,
        "thread_id": threading.get_native_id(),
        "timestamp_ns": time.monotonic_ns(),
        "frames": frames,
    }
    segment.update(extra)
    _segments.append(segment)
    return segment_id


def _install_unawaited_capture() -> bool:
    """Record only emitted CPython warnings and the allocation stack carried by their source."""
    if sys.implementation.name != "cpython":
        return False
    import inspect
    import warnings

    show = getattr(warnings, "_showwarnmsg", None)
    native_warning = getattr(getattr(warnings, "_warn_unawaited_coroutine", None), "__code__", None)
    if show is None or native_warning is None:
        return False

    def show_with_capture(message):
        source = message.source
        frame = sys._getframe(1)
        if (message.category is RuntimeWarning and frame.f_code is native_warning
                and inspect.iscoroutine(source) and inspect.getcoroutinestate(source) == inspect.CORO_CREATED):
            stack = []
            while frame is not None and len(stack) < STACK_LIMIT:
                stack.append(frame)
                frame = frame.f_back
            origin = source.cr_origin
            subject = dict(coroutine_object_id=str(id(source)), function_name=source.__qualname__,
                           coroutine_state=inspect.CORO_CREATED, timestamp_ns=time.monotonic_ns())
            with _lock:
                allocation = None
                if origin:
                    frames = [f"{name}:{line}:{file}" for file, line, name in reversed(origin[:STACK_LIMIT])]
                    # Both segments are read from one warning. The allocation
                    # happened earlier, at an unknown timestamp.
                    allocation = _push(None, "diagnostic_stacktrace", frames,
                                       sample_kind="unawaited_coroutine_origin", **subject)
                warning = _push(None, "diagnostic_stacktrace", _frame_strings(list(reversed(stack))),
                                sample_kind="unawaited_coroutine_warning", **subject)
                if allocation is not None:
                    _edges.append({"from": allocation, "to": warning, "kind": "unawaited_coroutine_origin"})
        show(message)

    depth = sys.get_coroutine_origin_tracking_depth()
    sys.set_coroutine_origin_tracking_depth(max(depth, STACK_LIMIT))
    warnings._showwarnmsg = show_with_capture
    return True


def _finish() -> None:
    if _unawaited_enabled:
        # Exception tracebacks can keep an unstarted coroutine in a cycle until
        # interpreter shutdown. Flush these warnings before writing the graph.
        import gc
        gc.collect()
    _write_output()


def _track_task(task: asyncio.Task[Any], *, adopted: bool = False) -> None:
    global _generation
    with _lock:
        if task in _task_ids:
            return
        _generation += 1
        task_id = f"python-asyncio-task-0x{id(task):x}-g{_generation}"
        _task_ids[task] = task_id
        coro = task.get_coro()
        function_name = getattr(coro, "__qualname__", type(coro).__qualname__)
        parent_id = None
        reason = "create"
        evidence = {}
        if adopted:
            # The C Task descriptor retains the creation stack when loop debug
            # was on. Its timestamp and creator identity are still unknown.
            descriptor = getattr(asyncio.Task, "_source_traceback", None)
            read_source = getattr(descriptor, "__get__", None)
            stack = read_source(task) if read_source and isinstance(task, asyncio.Task) else None
            if stack:
                evidence = dict(creation_evidence="asyncio-task-source-traceback",
                                timestamp_ns=None, observed_timestamp_ns=time.monotonic_ns())
            else:
                reason = "task_discovered"
        else:
            try:
                parent = asyncio.current_task(loop=task.get_loop())
            except RuntimeError:
                parent = None
            parent_id = _task_ids.get(parent) if parent is not None and parent is not task else None
            stack = traceback.extract_stack(limit=STACK_LIMIT + 8)[:-2]
        segment = _push(
            task_id,
            reason,
            _frame_strings(stack or []),
            function_name=function_name,
            coroutine_object_id=str(id(coro)),
            parent_coroutine_id=parent_id if parent_id in _active else None,
            **evidence,
        )
        if parent_id in _active:
            _edges.append({"from": segment, "to": _base.get(parent_id, _latest[parent_id]),
                           "kind": "coroutine_created_by"})
        if reason == "create":
            _base[task_id] = segment
        _latest[task_id] = segment
        _active.add(task_id)
    task.add_done_callback(_exit)


def _link_sample(task_id: str, segment: int) -> None:
    if task_id in _base:
        _edges.append({"from": _base[task_id], "to": segment, "kind": "base_to_sample"})
    _edges.append({"from": _latest[task_id], "to": segment, "kind": "same_task_next_sample"})
    _latest[task_id] = segment


def _sample_task(task: asyncio.Task[Any]) -> None:
    with _lock:
        task_id = _task_ids.get(task)
        if task_id is None or task_id not in _active or task.done():
            return
        # get_stack() normally exposes only the outer frame of a suspended
        # task. Follow retained Python awaitables to keep the framework and
        # application callees of that same task; opaque C awaiters end the
        # walk. This reads continuation state, without resuming the task.
        raw_frames = []
        current = task.get_coro()
        seen = set()
        while current is not None and id(current) not in seen and len(raw_frames) < STACK_LIMIT:
            seen.add(id(current))
            frame = (getattr(current, "cr_frame", None) or
                     getattr(current, "gi_frame", None) or
                     getattr(current, "ag_frame", None))
            if frame is not None:
                raw_frames.append(frame)
            current = (getattr(current, "cr_await", None) or
                       getattr(current, "gi_yieldfrom", None) or
                       getattr(current, "ag_await", None))
        frames = _frame_strings(raw_frames or task.get_stack(limit=STACK_LIMIT))
        if not frames:
            return
        segment = _push(task_id, "sample", frames, label="periodic-task-stack", sample_kind="task_snapshot")
        _link_sample(task_id, segment)


def _trace_exception(frame: Any, event: str, arg: Any):
    """Optional file-scoped diagnostic probe, before an exception unwinds."""
    if event == "call":
        return _trace_exception if frame.f_code.co_filename in EXCEPTION_FILES else None
    if event == "exception" and arg[0] not in (StopIteration, StopAsyncIteration, GeneratorExit):
        try:
            task = asyncio.current_task()
        except RuntimeError:
            task = None
        with _lock:
            task_id = _task_ids.get(task) if task is not None else None
            if task_id is not None and task_id in _active:
                raw = []
                cursor = frame
                while cursor is not None and len(raw) < STACK_LIMIT:
                    raw.append(cursor)
                    cursor = cursor.f_back
                segment = _push(task_id, "sample", _frame_strings(list(reversed(raw))),
                    label="exception:" + arg[0].__name__, sample_kind="scoped_exception",
                    exception_type=arg[0].__name__)
                _link_sample(task_id, segment)
    return _trace_exception


def _sample_loop(loop: asyncio.AbstractEventLoop) -> None:
    global _last_flush
    if loop.is_closed():
        return
    _sampling_tick_times_ns.append(time.monotonic_ns())
    try:
        for task in asyncio.all_tasks(loop):
            _sample_task(task)
        if FLUSH_SECONDS and time.monotonic() - _last_flush >= FLUSH_SECONDS:
            _write_output()
            _last_flush = time.monotonic()
    finally:
        if not loop.is_closed() and loop in _sampled_loops:
            _sample_handles[loop] = loop.call_later(SAMPLE_INTERVAL, _sample_loop, loop)


def _ensure_sampler(loop: asyncio.AbstractEventLoop) -> None:
    if loop in _sampled_loops:
        return
    _sampled_loops.add(loop)
    _sample_handles[loop] = loop.call_later(SAMPLE_INTERVAL, _sample_loop, loop)


def _install_loop_factory(loop: asyncio.AbstractEventLoop) -> None:
    if loop in _loop_factories:
        return
    previous = loop.get_task_factory()
    _loop_factories[loop] = previous

    def factory(current_loop: asyncio.AbstractEventLoop, coro: Any, **kwargs: Any):
        if previous is not None:
            task = previous(current_loop, coro, **kwargs)
        else:
            task = asyncio.tasks.Task(coro, loop=current_loop, **kwargs)
        _track_task(task)
        return task

    loop.set_task_factory(factory)


def detach_current_loop() -> bool:
    """Restore a pre-attach task factory without stopping target tasks."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return False
    restored = False
    if loop in _loop_factories:
        previous = _loop_factories.pop(loop)
        loop.set_task_factory(previous)
        restored = True
    handle = _sample_handles.pop(loop, None)
    if handle is not None:
        handle.cancel()
    _sampled_loops.discard(loop)
    for task in list(_task_ids.keys()):
        task.remove_done_callback(_exit)
    global _installed
    if REMOTE_MODE and _patched_create_task is not None \
            and asyncio.BaseEventLoop.create_task is _patched_create_task:
        asyncio.BaseEventLoop.create_task = _original_create_task
        _installed = False
        restored = True
    return restored


def _exit(task: asyncio.Task[Any]) -> None:
    with _lock:
        task_id = _task_ids.get(task)
        if task_id is None or task_id not in _active:
            return
        exit_reason = "cancel" if task.cancelled() else "return"
        if not task.cancelled():
            try:
                if task.exception() is not None:
                    exit_reason = "exception"
            except (asyncio.CancelledError, asyncio.InvalidStateError):
                exit_reason = "cancel"
        frames = _frame_strings(task.get_stack(limit=STACK_LIMIT))
        segment = _push(task_id, "exit", frames, exit_reason=exit_reason)
        _edges.append({"from": _latest[task_id], "to": segment, "kind": "same_task_exit"})
        _active.remove(task_id)
        _base.pop(task_id, None)
        _latest.pop(task_id, None)


def _write_output() -> None:
    process_id = os.getpid()
    output = OUTPUT if process_id == _output_owner_pid else OUTPUT.with_name(
        f"{OUTPUT.stem}.pid-{process_id}{OUTPUT.suffix}"
    )
    interpreter_id = 0
    interpreter_count = 1
    main_interpreter = True
    try:
        import _interpreters
        interpreter_id = int(_interpreters.get_current())
        interpreter_count = len(_interpreters.list_all())
        main_interpreter = _interpreters.get_current() == _interpreters.get_main()
    except (ImportError, AttributeError, TypeError):
        pass
    with _lock:
        graph = {
            "schema_version": 1,
            "language": "python",
            "runtime": "asyncio-sitecustomize",
            "frame_order": "root_to_leaf",
            "producer": {"name":"asyncio-frame-inspection", "identity_kind":"runtime-token-generation",
                         "continuation_storage":"stackless-state", "frame_order":"root_to_leaf",
                         "clock":"monotonic-ns", "observation_kind":"task_snapshot"},
            "segments": _segments,
            "edges": _edges,
            "active_coroutines": len(_active),
            "agent": {
                "python": sys.version.split()[0],
                "process_id": process_id,
                "boundary_journal_error": _boundary_journal_error,
                "parent_process_id": os.getppid(),
                "output_owner_process_id": _output_owner_pid,
                "sample_interval_seconds": SAMPLE_INTERVAL,
                "sampling_tick_times_ns": _sampling_tick_times_ns,
                "stack_limit": STACK_LIMIT,
                "transparent_launch": not _remote_attach,
                "remote_attach": _remote_attach,
                "seeded_tasks": _seeded_tasks,
                "interpreter_id": interpreter_id,
                "interpreter_count": interpreter_count,
                "main_interpreter": main_interpreter,
                "coverage_unit": "one-interpreter",
            },
        }
        if CAPTURE_UNAWAITED:
            graph["agent"]["unawaited_capture"] = _unawaited_enabled
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix(output.suffix + ".tmp")
    temporary.write_text(json.dumps(graph, indent=2) + "\n", encoding="utf-8")
    temporary.replace(output)


def install() -> None:
    global _installed, _original_create_task, _patched_create_task, _unawaited_enabled
    if _installed:
        return
    if not REMOTE_MODE and EXCEPTION_FILES and sys.gettrace() is not None:
        raise RuntimeError("File-scoped exception probes require an unused trace hook")
    _installed = True
    _original_create_task = asyncio.BaseEventLoop.create_task

    def create_task(loop: asyncio.AbstractEventLoop, coro: Any, *args: Any, **kwargs: Any):
        task = _original_create_task(loop, coro, *args, **kwargs)
        _track_task(task)
        _ensure_sampler(loop)
        return task

    asyncio.BaseEventLoop.create_task = create_task
    _patched_create_task = create_task
    if not REMOTE_MODE:
        if CAPTURE_UNAWAITED:
            _unawaited_enabled = _install_unawaited_capture()
        atexit.register(_finish)
        if EXCEPTION_FILES:
            sys.settrace(_trace_exception)
        if os.environ.get("COROPERF_BOUNDARY_SPEC"):
            from coroperf_semantic_probes import install as install_boundaries
            install_boundaries(_semantic_observation)


def _semantic_observation(label: str, payload: dict[str, Any], frame: Any = None) -> None:
    """Attach a selected semantic observation to the current runtime task."""
    try:
        task = asyncio.current_task()
    except RuntimeError:
        task = None
    with _lock:
        task_id = _task_ids.get(task) if task is not None else None
        raw = []
        cursor = frame or sys._getframe(1)
        while cursor is not None and len(raw) < STACK_LIMIT:
            raw.append(cursor)
            cursor = cursor.f_back
        segment = _push(task_id, "sample", _frame_strings(list(reversed(raw))),
                        label=label, sample_kind="semantic_boundary", semantic=payload)
        if task_id in _active:
            _link_sample(task_id, segment)
        if BOUNDARY_JOURNAL_DIR:
            _journal_boundary(_segments[segment])


def _journal_boundary(segment: dict[str, Any]) -> None:
    """Persist selected host evidence before a blocking call can stop progress."""
    global _boundary_journal_fd, _boundary_journal_pid, _boundary_journal_error
    if _boundary_journal_error:
        return
    pid = os.getpid()
    try:
        if _boundary_journal_pid != pid:
            if _boundary_journal_fd is not None:
                os.close(_boundary_journal_fd)
            directory = Path(BOUNDARY_JOURNAL_DIR)
            directory.mkdir(parents=True, exist_ok=True)
            _boundary_journal_fd = os.open(directory / f"host-progress.{pid}.jsonl",
                                          os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
            _boundary_journal_pid = pid
        encoded = (json.dumps({"process_id": pid, **segment}, ensure_ascii=False) + "\n").encode()
        view = memoryview(encoded)
        while view:
            written = os.write(_boundary_journal_fd, view)
            if written <= 0:
                raise OSError("Boundary journal write made no progress")
            view = view[written:]
    except OSError as error:
        _boundary_journal_error = str(error)
        print(f"CoroPerf boundary journal failed: {error}", file=sys.stderr)


def attach_current_loop() -> int:
    """Adopt tasks that existed before a CPython 3.14 remote attachment."""
    global _remote_attach, _seeded_tasks
    loop = asyncio.get_running_loop()
    _remote_attach = True
    seeded = 0
    for task in asyncio.all_tasks(loop):
        if task not in _task_ids:
            _track_task(task, adopted=True)
            seeded += 1
    _seeded_tasks += seeded
    _install_loop_factory(loop)
    _ensure_sampler(loop)
    return seeded


install()
